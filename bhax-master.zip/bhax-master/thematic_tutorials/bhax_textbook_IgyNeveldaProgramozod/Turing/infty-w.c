#include <stdbool.h>
int
main ()
{
  while(true);

  return 0;
}
